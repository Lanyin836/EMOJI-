#!/usr/bin/env python3
"""
Reproduce FPEI results from the de-identified emoji count matrix.

This script is intended for public reproducibility. It does not read raw comment
text. Instead, it reads:

    deidentified_emoji_count_matrix_for_FPEI.xlsx

and recalculates Table 1 frequencies, FPEI values, bootstrap confidence
intervals, and comment-level sensitivity results.
"""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd


SCRIPT_DIR = Path(__file__).resolve().parent
DATA_DIR = SCRIPT_DIR.parent
DEFAULT_MATRIX = DATA_DIR / "deidentified_emoji_count_matrix_for_FPEI.xlsx"
DEFAULT_OUTPUT = DATA_DIR / "emoji_FPEI_from_deidentified_matrix_check.xlsx"

RANDOM_SEED = 20260824
BOOTSTRAP_ITERATIONS = 5000

TABLE1_EMOJIS = [
    "赞",
    "流泪",
    "看",
    "捂脸",
    "玫瑰",
    "比心",
    "泪奔",
    "微笑",
    "泣不成声",
    "OK",
    "九转大肠",
    "舔屏",
    "呲牙",
    "尬笑",
    "偷笑",
    "送心",
    "色",
    "猪头",
    "不失礼貌的微笑",
    "抱抱你",
]


def count_columns() -> list[str]:
    return [f"{emoji}_count" for emoji in TABLE1_EMOJIS]


def calculate_from_matrix(matrix: pd.DataFrame, comment_level: bool = False) -> pd.DataFrame:
    values = matrix.copy()
    cols = count_columns()
    if comment_level:
        values[cols] = (values[cols] > 0).astype(int)

    fp = values[values["corpus_type"] == "false_positive"]
    pos = values[values["corpus_type"] == "model_positive"]
    neg = values[values["corpus_type"] == "model_negative"]

    rows = []
    for no, emoji in enumerate(TABLE1_EMOJIS, start=1):
        col = f"{emoji}_count"
        fp_count = int(fp[col].sum())
        pos_count = int(pos[col].sum())
        neg_count = int(neg[col].sum())
        fp_per_1000 = fp_count / len(fp) * 1000
        pos_per_1000 = pos_count / len(pos) * 1000
        neg_per_1000 = neg_count / len(neg) * 1000
        rows.append(
            {
                "No.": no,
                "emoji": emoji,
                "fp_count": fp_count,
                "pos_count": pos_count,
                "neg_count": neg_count,
                "fp_per_1000": fp_per_1000,
                "pos_per_1000": pos_per_1000,
                "neg_per_1000": neg_per_1000,
                "FPEI": fp_per_1000 / (neg_per_1000 + 1),
                "counting_mode": "comment-level" if comment_level else "occurrence-based",
            }
        )

    out = pd.DataFrame(rows)
    out["FPEI_rank_point"] = out["FPEI"].rank(method="min", ascending=False).astype(int)
    return out


def bootstrap_ci(
    matrix: pd.DataFrame,
    iterations: int,
    seed: int,
    comment_level: bool = False,
) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    groups = {
        "false_positive": matrix[matrix["corpus_type"] == "false_positive"].reset_index(drop=True),
        "model_positive": matrix[matrix["corpus_type"] == "model_positive"].reset_index(drop=True),
        "model_negative": matrix[matrix["corpus_type"] == "model_negative"].reset_index(drop=True),
    }
    records = {emoji: [] for emoji in TABLE1_EMOJIS}

    for _ in range(iterations):
        sampled = []
        for corpus_type, df in groups.items():
            idx = rng.integers(0, len(df), len(df))
            sampled.append(df.iloc[idx])
        boot = pd.concat(sampled, ignore_index=True)
        table = calculate_from_matrix(boot, comment_level=comment_level)
        for _, row in table.iterrows():
            records[row["emoji"]].append(
                (
                    row["fp_per_1000"],
                    row["pos_per_1000"],
                    row["neg_per_1000"],
                    row["FPEI"],
                )
            )

    rows = []
    for emoji in TABLE1_EMOJIS:
        arr = np.array(records[emoji], dtype=float)
        rows.append(
            {
                "emoji": emoji,
                "fp_per_1000_CI_low": np.percentile(arr[:, 0], 2.5),
                "fp_per_1000_CI_high": np.percentile(arr[:, 0], 97.5),
                "pos_per_1000_CI_low": np.percentile(arr[:, 1], 2.5),
                "pos_per_1000_CI_high": np.percentile(arr[:, 1], 97.5),
                "neg_per_1000_CI_low": np.percentile(arr[:, 2], 2.5),
                "neg_per_1000_CI_high": np.percentile(arr[:, 2], 97.5),
                "FPEI_bootstrap_median": np.percentile(arr[:, 3], 50),
                "FPEI_CI_low": np.percentile(arr[:, 3], 2.5),
                "FPEI_CI_high": np.percentile(arr[:, 3], 97.5),
            }
        )
    return pd.DataFrame(rows)


def add_ci(point: pd.DataFrame, ci: pd.DataFrame) -> pd.DataFrame:
    return point.merge(ci, on="emoji", how="left")


def main():
    parser = argparse.ArgumentParser(
        description="Recalculate FPEI results from the de-identified emoji count matrix."
    )
    parser.add_argument("--matrix", type=Path, default=DEFAULT_MATRIX)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--iterations", type=int, default=BOOTSTRAP_ITERATIONS)
    parser.add_argument("--seed", type=int, default=RANDOM_SEED)
    args = parser.parse_args()

    matrix = pd.read_excel(args.matrix, sheet_name="Emoji Count Matrix")

    occurrence = add_ci(
        calculate_from_matrix(matrix, comment_level=False),
        bootstrap_ci(matrix, args.iterations, args.seed, comment_level=False),
    )
    comment_level = add_ci(
        calculate_from_matrix(matrix, comment_level=True),
        bootstrap_ci(matrix, args.iterations, args.seed, comment_level=True),
    )

    sensitivity = occurrence[
        ["No.", "emoji", "FPEI", "FPEI_CI_low", "FPEI_CI_high", "FPEI_rank_point"]
    ].merge(
        comment_level[
            ["No.", "emoji", "FPEI", "FPEI_CI_low", "FPEI_CI_high", "FPEI_rank_point"]
        ],
        on=["No.", "emoji"],
        suffixes=("_occurrence", "_comment_level"),
    )
    sensitivity["FPEI_rank_change_comment_minus_occurrence"] = (
        sensitivity["FPEI_rank_point_comment_level"]
        - sensitivity["FPEI_rank_point_occurrence"]
    )

    summary = pd.DataFrame(
        [
            ["Input file", str(args.matrix)],
            ["Bootstrap iterations", args.iterations],
            ["Random seed", args.seed],
            [
                "Corpus sizes",
                "; ".join(
                    f"{k} N={v}"
                    for k, v in matrix["corpus_type"].value_counts().sort_index().items()
                ),
            ],
            ["FPEI formula", "FPEI = fp_per_1000 / (neg_per_1000 + 1)"],
            ["Privacy", "This script uses no raw comment text."],
        ],
        columns=["Item", "Value"],
    )

    with pd.ExcelWriter(args.output, engine="openpyxl") as writer:
        summary.to_excel(writer, index=False, sheet_name="Summary")
        occurrence.to_excel(writer, index=False, sheet_name="Occurrence Bootstrap CI")
        comment_level.to_excel(writer, index=False, sheet_name="Comment-Level Sensitivity")
        sensitivity.to_excel(writer, index=False, sheet_name="Sensitivity Comparison")

    print(f"Saved: {args.output}")


if __name__ == "__main__":
    main()
