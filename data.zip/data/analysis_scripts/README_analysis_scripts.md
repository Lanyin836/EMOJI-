# Analysis Scripts for Reproducibility

This folder contains reproducibility scripts prepared for the revised manuscript. The scripts reproduce the statistical analyses reported in the revised version from the saved derived datasets and annotation files. They are organized by analysis step rather than by the original exploratory workflow.

## Input Data

By default, the scripts read data from:

- `/Users/lanyin/Desktop/Plos one revision/data`
- `/Users/lanyin/Desktop/misclassified_corpus_652.xlsx`
- `/Users/lanyin/Desktop/positive corpus.xlsx`
- `/Users/lanyin/Desktop/negative corpus.xlsx`

The first folder contains the false-positive annotation files, the full five-category questionnaire coding files, and the blind review coding files. The corpus files are de-identified derived datasets used for frequency and FPEI calculations.

The raw social media comment corpus is not required for these scripts and is not redistributed because it may contain traceable user-generated textual information and may be subject to platform terms-of-service and copyright restrictions.

## Software Requirements

The scripts require Python 3 and the following packages:

- pandas
- numpy
- openpyxl
- matplotlib

## Scripts

### 01_FPEI_bootstrap_and_sensitivity.py

Reproduces the false-positive emoji frequency analysis reported in Table 1 and Section 4.2.

It calculates:

- `fp_per_1000`
- `pos_per_1000`
- `neg_per_1000`
- False-Positive Emoji Index (FPEI)
- comment-level sensitivity results
- non-parametric bootstrap confidence intervals for FPEI

Main output:

- `emoji_FPEI_bootstrap_CI_and_sensitivity.xlsx`

### 02_annotation_reliability.py

Reproduces the three-annotator reliability and corpus-inclusion sensitivity analyses reported in Section 4.1.

It calculates:

- Fleiss' kappa for binary offensiveness judgment
- Krippendorff's alpha for binary offensiveness judgment
- Krippendorff's alpha for 0-5 ratings
- ICC(2,1)
- ICC(2,k)
- observed binary agreement
- corpus-retention counts under alternative thresholds

Main output:

- `annotation_reliability_sensitivity_analysis.xlsx`

### 03_questionnaire_coding_reliability.py

Reproduces the blind review reliability analysis for the five-category questionnaire coding reported in Section 4.1.

It calculates:

- percentage agreement
- Cohen's kappa
- overall reliability
- post-00s reliability
- post-80s reliability
- item-level reliability

Main output:

- `emoji_questionnaire_blind_consistency_analysis.xlsx`

### 04_semantic_polarity_chisquare_and_figure1.py

Reproduces the semantic polarity scores, Figure 1 data, and Table 2 chi-square tests reported in Section 4.3.

It calculates:

- five-category counts by emoji and generation
- positive and negative proportions
- polarity scores using: positive proportion minus negative proportion
- quadrant positions
- Pearson chi-square tests on 2 x 5 semantic-category tables
- Cramer's V

Main outputs:

- `emoji_semantic_polarity_scores_20_items_by_filename.xlsx`
- `Figure1_quadrant_distribution_reproduced.png`

### 05_create_deidentified_emoji_count_matrix.py

Creates a de-identified derived emoji count matrix for reproducing the FPEI analysis without redistributing raw comment text.

It reads the local source corpus files and exports one row per anonymized analytical record, with only:

- anonymous comment ID
- corpus type
- occurrence counts for the 20 emojis reported in Table 1

The output does not include raw comment text, usernames, links, timestamps, profile information, or original row numbers.

Main output:

- `deidentified_emoji_count_matrix_for_FPEI.xlsx`

### 06_FPEI_from_deidentified_matrix.py

Reproduces the FPEI analysis from the de-identified emoji count matrix only.

This is the preferred public reproducibility script for Table 1, bootstrap confidence intervals, and comment-level sensitivity because it does not require access to raw comment text.

Main output:

- `emoji_FPEI_from_deidentified_matrix_check.xlsx`

## Notes

The Baidu Sentiment Analysis API screening step is not reproduced here because the API is a commercial closed-source system and may produce version-dependent results. These scripts begin from the saved model-classified and manually annotated derived datasets used in the revised analysis.

The scripts were prepared after reviewer revision to make the final reported analyses reproducible from the submitted derived datasets.
