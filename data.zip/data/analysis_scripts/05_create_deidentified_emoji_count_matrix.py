#!/usr/bin/env python3
"""
Create a de-identified emoji count matrix for FPEI reproducibility.

This script reads the local source corpus files that contain comment text and
exports a derived matrix without comment text. The output can be shared for
reproducibility because it retains only anonymous comment IDs, corpus labels,
and emoji occurrence counts for the 20 emojis reported in Table 1.

Default input files
-------------------
1. /Users/lanyin/Desktop/Plos one revision/misclassified_corpus_652.xlsx
   - sheet: Misclassified Corpus 652
   - text column: comment

2. /Users/lanyin/Desktop/Plos one revision/杨笠情感分析(全)_副本.xlsx
   - sheets: pos, neg
   - text column: text

Default output
--------------
/Users/lanyin/Desktop/Plos one revision/data/deidentified_emoji_count_matrix_for_FPEI.xlsx
"""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import pandas as pd


DEFAULT_FALSE_POSITIVE = Path(
    "/Users/lanyin/Desktop/Plos one revision/misclassified_corpus_652.xlsx"
)
DEFAULT_FULL_CORPUS = Path(
    "/Users/lanyin/Desktop/Plos one revision/杨笠情感分析(全)_副本.xlsx"
)
DEFAULT_OUTPUT = Path(
    "/Users/lanyin/Desktop/Plos one revision/data/deidentified_emoji_count_matrix_for_FPEI.xlsx"
)

TABLE1_TOKENS = [
    "[赞]",
    "[流泪]",
    "[看]",
    "[捂脸]",
    "[玫瑰]",
    "[比心]",
    "[泪奔]",
    "[微笑]",
    "[泣不成声]",
    "[OK]",
    "[九转大肠]",
    "[舔屏]",
    "[呲牙]",
    "[尬笑]",
    "[偷笑]",
    "[送心]",
    "[色]",
    "[猪头]",
    "[不失礼貌的微笑]",
    "[抱抱你]",
]


def label(token: str) -> str:
    return token[1:-1] if token.startswith("[") and token.endswith("]") else token


def count_token(text: str, token: str) -> int:
    if pd.isna(text):
        return 0
    return len(re.findall(re.escape(token), str(text)))


def build_matrix_for_series(texts: pd.Series, corpus_type: str, id_prefix: str) -> pd.DataFrame:
    rows = []
    for i, text in enumerate(texts.fillna("").astype(str), start=1):
        row = {
            "comment_id": f"{id_prefix}_{i:04d}",
            "corpus_type": corpus_type,
        }
        for token in TABLE1_TOKENS:
            row[f"{label(token)}_count"] = count_token(text, token)
        rows.append(row)
    return pd.DataFrame(rows)


def summarize_matrix(matrix: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for no, token in enumerate(TABLE1_TOKENS, start=1):
        emoji = label(token)
        col = f"{emoji}_count"
        fp = matrix.loc[matrix["corpus_type"] == "false_positive", col].sum()
        pos = matrix.loc[matrix["corpus_type"] == "model_positive", col].sum()
        neg = matrix.loc[matrix["corpus_type"] == "model_negative", col].sum()
        fp_n = (matrix["corpus_type"] == "false_positive").sum()
        pos_n = (matrix["corpus_type"] == "model_positive").sum()
        neg_n = (matrix["corpus_type"] == "model_negative").sum()
        fp_per_1000 = fp / fp_n * 1000
        pos_per_1000 = pos / pos_n * 1000
        neg_per_1000 = neg / neg_n * 1000
        rows.append(
            {
                "No.": no,
                "emoji": emoji,
                "emoji_token": token,
                "fp_count": int(fp),
                "pos_count": int(pos),
                "neg_count": int(neg),
                "fp_per_1000": fp_per_1000,
                "pos_per_1000": pos_per_1000,
                "neg_per_1000": neg_per_1000,
                "FPEI": fp_per_1000 / (neg_per_1000 + 1),
            }
        )
    return pd.DataFrame(rows)


def main():
    parser = argparse.ArgumentParser(
        description="Create a de-identified emoji count matrix for FPEI reproducibility."
    )
    parser.add_argument("--false-positive", type=Path, default=DEFAULT_FALSE_POSITIVE)
    parser.add_argument("--full-corpus", type=Path, default=DEFAULT_FULL_CORPUS)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    fp_df = pd.read_excel(args.false_positive, sheet_name="Misclassified Corpus 652")
    pos_df = pd.read_excel(args.full_corpus, sheet_name="pos")
    neg_df = pd.read_excel(args.full_corpus, sheet_name="neg")

    fp_matrix = build_matrix_for_series(
        fp_df["comment"], "false_positive", "FP"
    )
    pos_matrix = build_matrix_for_series(
        pos_df["text"], "model_positive", "POS"
    )
    neg_matrix = build_matrix_for_series(
        neg_df["text"], "model_negative", "NEG"
    )
    matrix = pd.concat([fp_matrix, pos_matrix, neg_matrix], ignore_index=True)
    summary = summarize_matrix(matrix)

    readme = pd.DataFrame(
        [
            [
                "Purpose",
                "De-identified derived emoji count matrix for reproducing Table 1, FPEI, bootstrap, and comment-level sensitivity analyses.",
            ],
            [
                "Privacy",
                "The matrix does not contain raw comment text, usernames, links, timestamps, profile information, or original row numbers.",
            ],
            [
                "Rows",
                "Each row represents one anonymized analytical corpus record. The false-positive corpus and model-positive corpus are represented as separate analytical corpora, consistent with the manuscript.",
            ],
            [
                "Columns",
                "Emoji columns contain occurrence counts for the 20 emojis reported in Table 1.",
            ],
            [
                "Corpus sizes",
                "false_positive N=652; model_positive N=3633; model_negative N=2020.",
            ],
            [
                "FPEI formula",
                "FPEI = fp_per_1000 / (neg_per_1000 + 1).",
            ],
        ],
        columns=["Item", "Description"],
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(args.output, engine="openpyxl") as writer:
        readme.to_excel(writer, index=False, sheet_name="README")
        matrix.to_excel(writer, index=False, sheet_name="Emoji Count Matrix")
        summary.to_excel(writer, index=False, sheet_name="Aggregate Check")

    print(f"Saved: {args.output}")
    print(f"Rows: {len(matrix)}")
    print(summary[["No.", "emoji", "fp_count", "pos_count", "neg_count", "FPEI"]].to_string(index=False))


if __name__ == "__main__":
    main()
