#!/usr/bin/env python3
"""
Reproduce the false-positive corpus annotation reliability and sensitivity checks.

Purpose
-------
This script reproduces the inter-annotator reliability statistics reported for
the three annotators' 0-5 offensiveness ratings and the corresponding binary
offensiveness decisions.

Default input files
-------------------
data/false-positive annotation/annotator_A_1-1000_merged.xlsx
data/false-positive annotation/annotator_B_1-1000_merged.xlsx
data/false-positive annotation/annotator_C_1-1000_merged.xlsx

Default output
--------------
annotation_reliability_sensitivity_analysis.xlsx

Main reported statistics
------------------------
- Fleiss' kappa for binary offensiveness decisions
- Krippendorff's alpha for binary offensiveness decisions
- Krippendorff's alpha for 0-5 ratings
- ICC(2,1) and ICC(2,k) for 0-5 ratings
- sensitivity checks for mean > 0, majority rule, and higher mean thresholds
"""

from __future__ import annotations

import argparse
import json
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


DEFAULT_DATA_DIR = Path("/Users/lanyin/Desktop/Plos one revision/data")
DEFAULT_OUTPUT = Path("annotation_reliability_sensitivity_analysis.xlsx")
CODERS = ["A", "B", "C"]


def clean_text(value):
    if value is None or pd.isna(value):
        return None
    value = str(value).strip()
    return value or None


def to_float(value):
    if value is None or pd.isna(value):
        return None
    try:
        return float(value)
    except (TypeError, ValueError):
        return None


def normalize_eval(value):
    value = clean_text(value)
    if value is None:
        return None
    key = value.lower()
    return {
        "positive": "pos",
        "postive": "pos",
        "pos": "pos",
        "negative": "neg",
        "neg": "neg",
        "neutral": "neu",
        "neutal": "neu",
        "neu": "neu",
    }.get(key, key)


def derive_binary(is_offensive, degree):
    """Derive binary judgment from the binary column and/or 0-5 rating."""
    binary = to_float(is_offensive)
    severity = to_float(degree)
    if binary in (0, 1):
        return int(binary)
    if severity is not None and severity > 0:
        return 1
    if severity == 0:
        return 0
    return None


def derive_rating(is_offensive, degree):
    """Derive a 0-5 rating; binary 0 rows with missing degree are assigned 0."""
    binary = derive_binary(is_offensive, degree)
    severity = to_float(degree)
    if severity is not None and 0 <= severity <= 5:
        return severity
    if binary == 0:
        return 0.0
    return None


def read_annotator(path: Path) -> dict[int, dict]:
    df = pd.read_excel(path, sheet_name=0)
    rows = {}
    for _, row in df.iterrows():
        idx = to_float(row.get("original_index"))
        if idx is None:
            continue
        idx = int(idx)
        rows[idx] = {
            "comment": clean_text(row.get("comment")),
            "eval": normalize_eval(row.get("1.总体评价（pos,neu,neg）*")),
            "binary": derive_binary(
                row.get("2.是否为冒犯用语(1,0)*"),
                row.get("3.冒犯程度（从低到高1-5）"),
            ),
            "rating": derive_rating(
                row.get("2.是否为冒犯用语(1,0)*"),
                row.get("3.冒犯程度（从低到高1-5）"),
            ),
            "row_status": clean_text(row.get("row_status")),
        }
    return rows


def build_records(sources: dict[str, Path]) -> list[dict]:
    data = {coder: read_annotator(path) for coder, path in sources.items()}
    records = []
    for idx in range(1, 1001):
        comment = next(
            (
                data[coder].get(idx, {}).get("comment")
                for coder in CODERS
                if data[coder].get(idx, {}).get("comment")
            ),
            None,
        )
        record = {"original_index": idx, "has_comment_text": comment is not None}
        for coder in CODERS:
            item = data[coder].get(idx, {})
            record[f"{coder}_eval"] = item.get("eval")
            record[f"{coder}_binary"] = item.get("binary")
            record[f"{coder}_rating"] = item.get("rating")
            record[f"{coder}_status"] = item.get("row_status")
        ratings = [record[f"{coder}_rating"] for coder in CODERS]
        binaries = [record[f"{coder}_binary"] for coder in CODERS]
        valid_ratings = [x for x in ratings if x is not None]
        valid_binaries = [x for x in binaries if x is not None]
        record["valid_rating_n"] = len(valid_ratings)
        record["mean_rating"] = float(np.mean(valid_ratings)) if valid_ratings else np.nan
        record["positive_rater_count"] = sum(1 for x in valid_ratings if x > 0)
        record["complete_three_ratings"] = len(valid_ratings) == 3
        record["complete_three_binary"] = len(valid_binaries) == 3
        records.append(record)
    return records


def fleiss_kappa_binary(records):
    matrix = []
    for row in records:
        vals = [row[f"{coder}_binary"] for coder in CODERS]
        if all(v in (0, 1) for v in vals):
            matrix.append([vals.count(0), vals.count(1)])
    matrix = np.asarray(matrix, dtype=float)
    n = len(matrix)
    k = matrix.sum(axis=1)[0]
    p = matrix.sum(axis=0) / (n * k)
    p_i = ((matrix * matrix).sum(axis=1) - k) / (k * (k - 1))
    observed = p_i.mean()
    expected = (p * p).sum()
    return {
        "N": n,
        "value": float((observed - expected) / (1 - expected)),
        "observed_agreement": float(observed),
        "expected_agreement": float(expected),
        "notes": json.dumps({"0": float(p[0]), "1": float(p[1])}),
    }


def krippendorff_alpha(rows, metric="nominal"):
    usable = []
    for row in rows:
        vals = [x for x in row if x is not None and not pd.isna(x)]
        if len(vals) >= 2:
            usable.append(vals)
    cats = sorted({x for vals in usable for x in vals})
    counts = Counter(x for vals in usable for x in vals)
    total = sum(counts.values())

    def distance(a, b):
        if metric == "nominal":
            return 0.0 if a == b else 1.0
        return float((a - b) ** 2)

    do_num = 0.0
    do_den = 0
    for vals in usable:
        for i, a in enumerate(vals):
            for j, b in enumerate(vals):
                if i != j:
                    do_num += distance(a, b)
                    do_den += 1
    observed_disagreement = do_num / do_den

    de_num = 0.0
    for a in cats:
        for b in cats:
            if a != b:
                de_num += counts[a] * counts[b] * distance(a, b)
    expected_disagreement = de_num / (total * (total - 1))
    return float(1 - observed_disagreement / expected_disagreement)


def icc_2way_absolute(records):
    values = []
    for row in records:
        vals = [row[f"{coder}_rating"] for coder in CODERS]
        if all(v is not None and not pd.isna(v) for v in vals):
            values.append(vals)
    x = np.asarray(values, dtype=float)
    n, k = x.shape
    target_means = x.mean(axis=1)
    rater_means = x.mean(axis=0)
    grand_mean = x.mean()
    msr = k * np.sum((target_means - grand_mean) ** 2) / (n - 1)
    msc = n * np.sum((rater_means - grand_mean) ** 2) / (k - 1)
    mse = (
        np.sum((x - target_means[:, None] - rater_means[None, :] + grand_mean) ** 2)
        / ((n - 1) * (k - 1))
    )
    icc21 = (msr - mse) / (msr + (k - 1) * mse + k * (msc - mse) / n)
    icc2k = (msr - mse) / (msr + (msc - mse) / n)
    return {
        "N": int(n),
        "raters": int(k),
        "ICC(2,1)": float(icc21),
        "ICC(2,k)": float(icc2k),
        "MSR": float(msr),
        "MSC": float(msc),
        "MSE": float(mse),
    }


def cohen_kappa(pairs, labels):
    pairs = [(a, b) for a, b in pairs if a in labels and b in labels]
    n = len(pairs)
    counts_a = Counter(a for a, _ in pairs)
    counts_b = Counter(b for _, b in pairs)
    observed = sum(1 for a, b in pairs if a == b) / n
    expected = sum((counts_a[label] / n) * (counts_b[label] / n) for label in labels)
    return {
        "N": n,
        "value": float((observed - expected) / (1 - expected)),
        "observed_agreement": float(observed),
        "expected_agreement": float(expected),
    }


def sensitivity_table(records):
    all_valid = [r for r in records if r["has_comment_text"] and r["valid_rating_n"] > 0]
    complete = [r for r in records if r["complete_three_ratings"]]

    all_rules = [
        ("Original inclusive rule: mean rating > 0", lambda r: r["mean_rating"] > 0),
        ("Mean threshold: mean rating >= 1.0", lambda r: r["mean_rating"] >= 1.0),
        ("Mean threshold: mean rating >= 1.5", lambda r: r["mean_rating"] >= 1.5),
        ("Mean threshold: mean rating >= 2.0", lambda r: r["mean_rating"] >= 2.0),
    ]
    complete_rules = [
        ("Original inclusive rule: mean rating > 0", lambda r: r["mean_rating"] > 0),
        ("Majority rule: at least 2 of 3 ratings > 0", lambda r: r["positive_rater_count"] >= 2),
        ("Unanimous rule: all 3 ratings > 0", lambda r: r["positive_rater_count"] == 3),
        ("Mean threshold: mean rating >= 1.0", lambda r: r["mean_rating"] >= 1.0),
        ("Mean threshold: mean rating >= 1.5", lambda r: r["mean_rating"] >= 1.5),
        ("Mean threshold: mean rating >= 2.0", lambda r: r["mean_rating"] >= 2.0),
    ]

    rows = []
    for sample, population, rules in [
        ("All rows with at least one valid rating", all_valid, all_rules),
        ("Complete three-rater subset", complete, complete_rules),
    ]:
        baseline = sum(1 for r in population if r["mean_rating"] > 0)
        for rule, fn in rules:
            retained = sum(1 for r in population if fn(r))
            rows.append(
                {
                    "sample": sample,
                    "rule": rule,
                    "eligible_n": len(population),
                    "retained_n": retained,
                    "retained_pct": retained / len(population),
                    "retention_vs_original_in_same_sample": retained / baseline,
                }
            )
    return pd.DataFrame(rows)


def make_output(records, output_path: Path):
    complete_binary = [r for r in records if r["complete_three_binary"]]
    complete_rating = [r for r in records if r["complete_three_ratings"]]
    binary_rows = [[r[f"{coder}_binary"] for coder in CODERS] for r in complete_binary]
    rating_rows = [[r[f"{coder}_rating"] for coder in CODERS] for r in complete_rating]

    fleiss = fleiss_kappa_binary(records)
    icc = icc_2way_absolute(records)
    reliability = pd.DataFrame(
        [
            {
                "metric": "Fleiss' kappa",
                "scale": "binary offensiveness (>0 vs 0)",
                **fleiss,
            },
            {
                "metric": "Krippendorff's alpha",
                "scale": "binary offensiveness (>0 vs 0), nominal",
                "N": len(binary_rows),
                "value": krippendorff_alpha(binary_rows, "nominal"),
                "observed_agreement": np.nan,
                "expected_agreement": np.nan,
                "notes": "",
            },
            {
                "metric": "Krippendorff's alpha",
                "scale": "0-5 rating, interval/squared distance",
                "N": len(rating_rows),
                "value": krippendorff_alpha(rating_rows, "interval"),
                "observed_agreement": np.nan,
                "expected_agreement": np.nan,
                "notes": "",
            },
            {
                "metric": "ICC(2,1)",
                "scale": "0-5 rating, single-measure absolute agreement",
                "N": icc["N"],
                "value": icc["ICC(2,1)"],
                "observed_agreement": np.nan,
                "expected_agreement": np.nan,
                "notes": "",
            },
            {
                "metric": "ICC(2,k)",
                "scale": "0-5 rating, average-measure absolute agreement",
                "N": icc["N"],
                "value": icc["ICC(2,k)"],
                "observed_agreement": np.nan,
                "expected_agreement": np.nan,
                "notes": "",
            },
        ]
    )

    pairwise_rows = []
    binary_confusion_rows = []
    for c1, c2 in [("A", "B"), ("A", "C"), ("B", "C")]:
        pairs = [(r[f"{c1}_binary"], r[f"{c2}_binary"]) for r in records]
        result = cohen_kappa(pairs, [0, 1])
        pairwise_rows.append(
            {
                "coder_pair": f"{c1}-{c2}",
                "metric": "Cohen's kappa",
                "scale": "binary offensiveness (>0 vs 0)",
                **result,
            }
        )
        counts = defaultdict(int)
        for a, b in pairs:
            if a in (0, 1) and b in (0, 1):
                counts[(a, b)] += 1
        for a in [0, 1]:
            for b in [0, 1]:
                binary_confusion_rows.append(
                    {"coder_pair": f"{c1}-{c2}", f"{c1}_binary": a, f"{c2}_binary": b, "count": counts[(a, b)]}
                )

    missing = []
    for coder in CODERS:
        statuses = Counter(r[f"{coder}_status"] for r in records)
        missing.append(
            {
                "coder": coder,
                "valid_binary_n": sum(1 for r in records if r[f"{coder}_binary"] is not None),
                "valid_rating_n": sum(1 for r in records if r[f"{coder}_rating"] is not None),
                "status_ok": statuses.get("ok", 0),
                "status_blank_in_source": statuses.get("blank_in_source", 0),
                "status_missing_from_source": statuses.get("missing_from_source", 0),
            }
        )

    readme = pd.DataFrame(
        [
            ["Input", "Three merged annotator workbooks from data/false-positive annotation."],
            ["Rule", "Ratings were derived from the 0-5 degree column when present; binary 0 rows with missing degree were assigned rating 0; other missing ratings were not imputed."],
            ["Complete 3-rater binary N", len(binary_rows)],
            ["Complete 3-rater rating N", len(rating_rows)],
            ["Important caveat", "Reliability statistics are calculated on complete-rater subsets where required."],
        ],
        columns=["Item", "Description"],
    )
    notes = pd.DataFrame(
        [
            ["Binary reliability", "Fleiss' kappa and nominal Krippendorff's alpha were calculated for 0 versus >0 offensiveness decisions."],
            ["Severity reliability", "Interval Krippendorff's alpha and two-way random-effects absolute-agreement ICC were calculated for original 0-5 ratings."],
            ["Sensitivity", "The original inclusive mean > 0 rule was compared with stricter inclusion rules."],
        ],
        columns=["Item", "Description"],
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        readme.to_excel(writer, index=False, sheet_name="README")
        reliability.to_excel(writer, index=False, sheet_name="Reliability")
        pd.DataFrame(pairwise_rows).to_excel(writer, index=False, sheet_name="Pairwise Binary")
        pd.DataFrame(binary_confusion_rows).to_excel(writer, index=False, sheet_name="Binary Confusion")
        sensitivity_table(records).to_excel(writer, index=False, sheet_name="Sensitivity")
        pd.DataFrame(missing).to_excel(writer, index=False, sheet_name="Missing Summary")
        notes.to_excel(writer, index=False, sheet_name="Notes")


def parse_args():
    parser = argparse.ArgumentParser(description="Calculate annotation reliability and sensitivity checks.")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    return parser.parse_args()


def main():
    args = parse_args()
    sources = {
        "A": args.data_dir / "false-positive annotation" / "annotator_A_1-1000_merged.xlsx",
        "B": args.data_dir / "false-positive annotation" / "annotator_B_1-1000_merged.xlsx",
        "C": args.data_dir / "false-positive annotation" / "annotator_C_1-1000_merged.xlsx",
    }
    records = build_records(sources)
    make_output(records, args.output)
    print(f"Saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()
