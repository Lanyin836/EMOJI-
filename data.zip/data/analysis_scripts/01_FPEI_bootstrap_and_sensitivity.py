#!/usr/bin/env python3
"""
Reproduce Table 1 and the FPEI bootstrap/sensitivity analyses.

Purpose
-------
This script calculates emoji frequencies, the False-Positive Emoji Index
(FPEI), bootstrap confidence intervals, and a comment-level sensitivity check.

Default input files
-------------------
1. /Users/lanyin/Desktop/Plos one revision/misclassified_corpus_652.xlsx
   - manually validated false-positive corpus
   - text column: comment

2. /Users/lanyin/Desktop/positive corpus.xlsx
   - model-classified positive corpus
   - text column: text

3. /Users/lanyin/Desktop/negative corpus.xlsx
   - model-classified negative corpus
   - text column: text

Output
------
emoji_FPEI_bootstrap_CI_and_sensitivity.xlsx

Notes
-----
FPEI is a descriptive risk indicator:

    FPEI = fp_per_1000 / (neg_per_1000 + 1)

where fp_per_1000 is the normalized frequency of an emoji in the manually
validated false-positive corpus, and neg_per_1000 is its normalized frequency
in the model-classified negative corpus. Add-one smoothing prevents undefined
ratios when an emoji is absent from the negative corpus.
"""

from __future__ import annotations

import argparse
import re
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd


DEFAULT_FALSE_POSITIVE = Path(
    "/Users/lanyin/Desktop/Plos one revision/misclassified_corpus_652.xlsx"
)
DEFAULT_POSITIVE = Path("/Users/lanyin/Desktop/positive corpus.xlsx")
DEFAULT_NEGATIVE = Path("/Users/lanyin/Desktop/negative corpus.xlsx")
DEFAULT_OUTPUT = Path("emoji_FPEI_bootstrap_CI_and_sensitivity.xlsx")

RANDOM_SEED = 20260824
BOOTSTRAP_ITERATIONS = 5000
TOP_N = 20

# Final Table 1 emoji order used in the manuscript. The table is sorted by
# normalized frequency in the false-positive corpus; when multiple emojis have
# the same false-positive count near the cutoff, this canonical order reproduces
# the manuscript table exactly.
CANONICAL_TABLE1_TOKENS = [
    "[赞]",
    "[流泪]",
    "[看]",
    "[捂脸]",
    "[玫瑰]",
    "[比心]",
    "[泪奔]",
    "[微笑]",
    "[泣不成声]",
    "[OK]",
    "[九转大肠]",
    "[舔屏]",
    "[呲牙]",
    "[尬笑]",
    "[偷笑]",
    "[送心]",
    "[色]",
    "[猪头]",
    "[不失礼貌的微笑]",
    "[抱抱你]",
]


# Platform emoji in the corpus may appear as Chinese labels in square brackets,
# such as [赞] or [九转大肠]. The unicode ranges cover standard emoji characters.
BRACKET_EMOJI_RE = re.compile(r"\[[^\[\]\s]{1,20}\]")
UNICODE_EMOJI_RE = re.compile(
    "["
    "\U0001F1E6-\U0001F1FF"  # flags
    "\U0001F300-\U0001F5FF"  # symbols and pictographs
    "\U0001F600-\U0001F64F"  # emoticons
    "\U0001F680-\U0001F6FF"  # transport and map
    "\U0001F700-\U0001F77F"
    "\U0001F780-\U0001F7FF"
    "\U0001F800-\U0001F8FF"
    "\U0001F900-\U0001F9FF"
    "\U0001FA70-\U0001FAFF"
    "\u2600-\u27BF"
    "]"
)


def read_text_column(path: Path, preferred_column: str) -> list[str]:
    """Read a workbook and return non-missing comment text values."""
    if not path.exists():
        raise FileNotFoundError(f"Input file not found: {path}")

    df = pd.read_excel(path)
    if preferred_column in df.columns:
        column = preferred_column
    elif "text" in df.columns:
        column = "text"
    elif "comment" in df.columns:
        column = "comment"
    else:
        raise ValueError(
            f"Could not find a text column in {path}. "
            f"Available columns: {list(df.columns)}"
        )

    return df[column].fillna("").astype(str).tolist()


def extract_emoji_tokens(text: str) -> list[str]:
    """Extract bracket-coded platform emoji and unicode emoji tokens."""
    bracket_tokens = BRACKET_EMOJI_RE.findall(text)
    text_without_brackets = BRACKET_EMOJI_RE.sub(" ", text)
    unicode_tokens = UNICODE_EMOJI_RE.findall(text_without_brackets)
    return bracket_tokens + unicode_tokens


def emoji_label(token: str) -> str:
    """Return a display label without square brackets when applicable."""
    if token.startswith("[") and token.endswith("]"):
        return token[1:-1]
    return token


def count_tokens(comments: list[str], comment_level: bool = False) -> Counter:
    """Count emoji tokens in a corpus.

    If comment_level=True, multiple occurrences of the same emoji within one
    comment are counted only once.
    """
    counts: Counter = Counter()
    for comment in comments:
        tokens = extract_emoji_tokens(comment)
        if comment_level:
            tokens = sorted(set(tokens))
        counts.update(tokens)
    return counts


def calculate_table(
    false_positive_comments: list[str],
    positive_comments: list[str],
    negative_comments: list[str],
    selected_tokens: list[str] | None = None,
    comment_level: bool = False,
) -> pd.DataFrame:
    """Calculate frequencies and FPEI for selected tokens."""
    fp_counts = count_tokens(false_positive_comments, comment_level=comment_level)
    pos_counts = count_tokens(positive_comments, comment_level=comment_level)
    neg_counts = count_tokens(negative_comments, comment_level=comment_level)

    if selected_tokens is None:
        canonical_present = [
            token for token in CANONICAL_TABLE1_TOKENS if token in fp_counts
        ]
        if len(canonical_present) >= TOP_N:
            selected_tokens = canonical_present[:TOP_N]
        else:
            selected_tokens = canonical_present[:]
            for token, _ in fp_counts.most_common():
                if token not in selected_tokens:
                    selected_tokens.append(token)
                if len(selected_tokens) == TOP_N:
                    break

    rows = []
    for rank, token in enumerate(selected_tokens, start=1):
        fp_count = fp_counts.get(token, 0)
        pos_count = pos_counts.get(token, 0)
        neg_count = neg_counts.get(token, 0)

        fp_per_1000 = fp_count / len(false_positive_comments) * 1000
        pos_per_1000 = pos_count / len(positive_comments) * 1000
        neg_per_1000 = neg_count / len(negative_comments) * 1000
        fpei = fp_per_1000 / (neg_per_1000 + 1)

        rows.append(
            {
                "No.": rank,
                "emoji": emoji_label(token),
                "emoji_token": token,
                "fp_count": fp_count,
                "pos_count": pos_count,
                "neg_count": neg_count,
                "fp_per_1000": fp_per_1000,
                "pos_per_1000": pos_per_1000,
                "neg_per_1000": neg_per_1000,
                "FPEI": fpei,
                "counting_mode": "comment-level"
                if comment_level
                else "occurrence-based",
            }
        )

    table = pd.DataFrame(rows)
    table["FPEI_rank_point"] = table["FPEI"].rank(
        method="min", ascending=False
    ).astype(int)
    return table


def bootstrap_ci(
    false_positive_comments: list[str],
    positive_comments: list[str],
    negative_comments: list[str],
    selected_tokens: list[str],
    iterations: int,
    seed: int,
    comment_level: bool = False,
) -> pd.DataFrame:
    """Estimate bootstrap CIs for frequencies and FPEI."""
    rng = np.random.default_rng(seed)
    n_fp = len(false_positive_comments)
    n_pos = len(positive_comments)
    n_neg = len(negative_comments)

    fp_arr = np.array(false_positive_comments, dtype=object)
    pos_arr = np.array(positive_comments, dtype=object)
    neg_arr = np.array(negative_comments, dtype=object)

    records = {token: [] for token in selected_tokens}

    for _ in range(iterations):
        fp_sample = fp_arr[rng.integers(0, n_fp, n_fp)].tolist()
        pos_sample = pos_arr[rng.integers(0, n_pos, n_pos)].tolist()
        neg_sample = neg_arr[rng.integers(0, n_neg, n_neg)].tolist()

        table = calculate_table(
            fp_sample,
            pos_sample,
            neg_sample,
            selected_tokens=selected_tokens,
            comment_level=comment_level,
        )
        for _, row in table.iterrows():
            records[row["emoji_token"]].append(
                (
                    row["fp_per_1000"],
                    row["pos_per_1000"],
                    row["neg_per_1000"],
                    row["FPEI"],
                )
            )

    rows = []
    for token in selected_tokens:
        arr = np.array(records[token], dtype=float)
        rows.append(
            {
                "emoji_token": token,
                "fp_per_1000_CI_low": np.percentile(arr[:, 0], 2.5),
                "fp_per_1000_CI_high": np.percentile(arr[:, 0], 97.5),
                "pos_per_1000_CI_low": np.percentile(arr[:, 1], 2.5),
                "pos_per_1000_CI_high": np.percentile(arr[:, 1], 97.5),
                "neg_per_1000_CI_low": np.percentile(arr[:, 2], 2.5),
                "neg_per_1000_CI_high": np.percentile(arr[:, 2], 97.5),
                "FPEI_bootstrap_median": np.percentile(arr[:, 3], 50),
                "FPEI_CI_low": np.percentile(arr[:, 3], 2.5),
                "FPEI_CI_high": np.percentile(arr[:, 3], 97.5),
            }
        )
    return pd.DataFrame(rows)


def add_bootstrap_columns(
    point_table: pd.DataFrame, ci_table: pd.DataFrame
) -> pd.DataFrame:
    """Merge point estimates with bootstrap intervals."""
    return point_table.merge(ci_table, on="emoji_token", how="left")


def write_workbook(
    output_path: Path,
    summary: pd.DataFrame,
    occurrence_table: pd.DataFrame,
    comment_table: pd.DataFrame,
    sensitivity_table: pd.DataFrame,
) -> None:
    """Write all results to one Excel workbook."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    notes = pd.DataFrame(
        [
            ["Workbook purpose", "FPEI calculation, bootstrap CIs, and comment-level sensitivity analysis."],
            ["FPEI formula", "FPEI = fp_per_1000 / (neg_per_1000 + 1)."],
            ["fp_per_1000", "Emoji occurrence frequency per 1,000 comments in the manually validated false-positive corpus."],
            ["pos_per_1000", "Emoji occurrence frequency per 1,000 comments in the model-classified positive corpus."],
            ["neg_per_1000", "Emoji occurrence frequency per 1,000 comments in the model-classified negative corpus."],
            ["Bootstrap unit", f"Comment-level non-parametric bootstrap resampling within each corpus; {BOOTSTRAP_ITERATIONS} iterations."],
            ["Occurrence-based counting", "Repeated occurrences of the same emoji in one comment are counted as separate occurrences."],
            ["Comment-level sensitivity", "Multiple occurrences of the same emoji within one comment are counted only once."],
            ["Interpretation", "FPEI is a descriptive risk indicator, not an inferential test statistic or direct evidence of stable semantic reversal."],
        ],
        columns=["Item", "Description"],
    )

    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        summary.to_excel(writer, index=False, sheet_name="Summary")
        occurrence_table.to_excel(writer, index=False, sheet_name="Occurrence Bootstrap CI")
        comment_table.to_excel(writer, index=False, sheet_name="Comment-Level Sensitivity")
        sensitivity_table.to_excel(writer, index=False, sheet_name="Sensitivity Comparison")
        notes.to_excel(writer, index=False, sheet_name="Notes")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Calculate FPEI, bootstrap confidence intervals, and comment-level sensitivity results."
    )
    parser.add_argument("--false-positive", type=Path, default=DEFAULT_FALSE_POSITIVE)
    parser.add_argument("--positive", type=Path, default=DEFAULT_POSITIVE)
    parser.add_argument("--negative", type=Path, default=DEFAULT_NEGATIVE)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    parser.add_argument("--iterations", type=int, default=BOOTSTRAP_ITERATIONS)
    parser.add_argument("--seed", type=int, default=RANDOM_SEED)
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    false_positive_comments = read_text_column(args.false_positive, "comment")
    positive_comments = read_text_column(args.positive, "text")
    negative_comments = read_text_column(args.negative, "text")

    occurrence_point = calculate_table(
        false_positive_comments,
        positive_comments,
        negative_comments,
        selected_tokens=None,
        comment_level=False,
    )
    selected_tokens = occurrence_point["emoji_token"].tolist()

    occurrence_ci = bootstrap_ci(
        false_positive_comments,
        positive_comments,
        negative_comments,
        selected_tokens,
        iterations=args.iterations,
        seed=args.seed,
        comment_level=False,
    )
    occurrence_table = add_bootstrap_columns(occurrence_point, occurrence_ci)

    comment_point = calculate_table(
        false_positive_comments,
        positive_comments,
        negative_comments,
        selected_tokens=selected_tokens,
        comment_level=True,
    )
    comment_ci = bootstrap_ci(
        false_positive_comments,
        positive_comments,
        negative_comments,
        selected_tokens,
        iterations=args.iterations,
        seed=args.seed,
        comment_level=True,
    )
    comment_table = add_bootstrap_columns(comment_point, comment_ci)

    sensitivity_table = occurrence_table[
        ["No.", "emoji", "FPEI", "FPEI_CI_low", "FPEI_CI_high", "FPEI_rank_point"]
    ].merge(
        comment_table[
            ["No.", "emoji", "FPEI", "FPEI_CI_low", "FPEI_CI_high", "FPEI_rank_point"]
        ],
        on=["No.", "emoji"],
        suffixes=("_occurrence", "_comment_level"),
    )
    sensitivity_table["FPEI_rank_change_comment_minus_occurrence"] = (
        sensitivity_table["FPEI_rank_point_comment_level"]
        - sensitivity_table["FPEI_rank_point_occurrence"]
    )

    summary = pd.DataFrame(
        [
            ["Bootstrap iterations", args.iterations],
            ["Random seed", args.seed],
            [
                "Corpus sizes",
                f"false-positive N={len(false_positive_comments)}; "
                f"positive N={len(positive_comments)}; "
                f"negative N={len(negative_comments)}",
            ],
            ["FPEI formula", "FPEI = fp_per_1000 / (neg_per_1000 + 1)"],
            [
                "Bootstrap unit",
                "comment-level non-parametric bootstrap resampling within each corpus",
            ],
            [
                "Key interpretation",
                "Occurrence-based FPEI reproduces Table 1. Comment-level sensitivity counts multiple occurrences of the same emoji within one comment only once.",
            ],
            [
                "Use in manuscript",
                "Report FPEI as a descriptive indicator; cite bootstrap CIs to show uncertainty, especially for emojis with sparse or zero negative-corpus frequencies.",
            ],
        ],
        columns=["Item", "Value"],
    )

    write_workbook(args.output, summary, occurrence_table, comment_table, sensitivity_table)
    print(f"Saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()
