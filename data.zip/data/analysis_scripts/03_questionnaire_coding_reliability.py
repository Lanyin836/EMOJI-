#!/usr/bin/env python3
"""
Reproduce the blind reliability check for five-category questionnaire coding.

Purpose
-------
This script compares the initial five-category semantic coding by Annotator 1
with the blind review coding by Annotator 2.

Default input folders
---------------------
data/types-annotator 1/
data/types-annotator 2/

Default output
--------------
emoji_questionnaire_blind_consistency_analysis.xlsx

Main reported statistics
------------------------
- 1,000 blind review samples
- 993 uniquely matched usable samples
- 7 ambiguous excluded samples
- overall percentage agreement and Cohen's kappa
- generation-specific and emoji-specific reliability summaries
"""

from __future__ import annotations

import argparse
import re
from collections import Counter, defaultdict
from pathlib import Path

import numpy as np
import pandas as pd


DEFAULT_DATA_DIR = Path("/Users/lanyin/Desktop/Plos one revision/data")
DEFAULT_OUTPUT = Path("emoji_questionnaire_blind_consistency_analysis.xlsx")
CATEGORIES = ["正向类", "负向类", "戏谑类", "中性类", "不熟悉类"]


def clean(value):
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def parse_no_label(path: Path) -> tuple[int, str]:
    name = path.stem
    match = re.match(r"\s*(\d+)[\._、\s-]*(.+)", name)
    if not match:
        raise ValueError(f"Could not parse emoji number from filename: {path.name}")
    no = int(match.group(1))
    label = match.group(2)
    label = re.sub(r"_随机复核抽样.*$", "", label)
    label = re.sub(r"_已标注.*$", "", label)
    label = label.replace(" ", "").strip("_-")
    return no, label


def find_header_row(df: pd.DataFrame) -> int:
    for i in range(len(df)):
        row = [clean(x) for x in df.iloc[i].tolist()]
        if "00后 response" in row and "80后 response" in row:
            return i
    raise ValueError("Could not find questionnaire coding header row.")


def read_coding_file(path: Path) -> list[dict]:
    no, label = parse_no_label(path)
    raw = pd.read_excel(path, sheet_name=0, header=None, dtype=str)
    header_idx = find_header_row(raw)
    header = [clean(x) for x in raw.iloc[header_idx].tolist()]
    data = raw.iloc[header_idx + 1 :].copy()
    data.columns = header

    rows = []
    for _, row in data.iterrows():
        for generation in ["00后", "80后"]:
            response = clean(row.get(f"{generation} response"))
            coding = clean(row.get(f"{generation} reviewer coding"))
            if response and coding:
                rows.append(
                    {
                        "No.": no,
                        "Emoji": label,
                        "Generation": generation,
                        "Response": response,
                        "Coding": coding,
                        "Source file": str(path),
                    }
                )
    return rows


def cohen_kappa(labels_a, labels_b, categories=CATEGORIES):
    pairs = [(a, b) for a, b in zip(labels_a, labels_b) if a in categories and b in categories]
    n = len(pairs)
    if n == 0:
        return np.nan, np.nan, np.nan
    counts_a = Counter(a for a, _ in pairs)
    counts_b = Counter(b for _, b in pairs)
    observed = sum(1 for a, b in pairs if a == b) / n
    expected = sum((counts_a[c] / n) * (counts_b[c] / n) for c in categories)
    kappa = (observed - expected) / (1 - expected) if expected != 1 else np.nan
    return observed, expected, kappa


def summarize(rows: list[dict], scope: str) -> dict:
    labels_a = [r["Original coding"] for r in rows]
    labels_b = [r["Reviewer coding"] for r in rows]
    observed, expected, kappa = cohen_kappa(labels_a, labels_b)
    agreements = sum(a == b for a, b in zip(labels_a, labels_b))
    return {
        "Scope": scope,
        "Usable matched N": len(rows),
        "Agreements": agreements,
        "Disagreements": len(rows) - agreements,
        "Percent agreement": observed,
        "Chance agreement": expected,
        "Cohen's kappa": kappa,
    }


def confusion_matrix(rows: list[dict]) -> pd.DataFrame:
    table = pd.DataFrame(0, index=CATEGORIES, columns=CATEGORIES, dtype=int)
    for r in rows:
        a = r["Original coding"]
        b = r["Reviewer coding"]
        if a in CATEGORIES and b in CATEGORIES:
            table.loc[a, b] += 1
    table["Row total"] = table.sum(axis=1)
    total_row = table.sum(axis=0).to_frame().T
    total_row.index = ["Column total"]
    out = pd.concat([table, total_row])
    out.insert(0, "Original \\ Reviewer", out.index)
    return out.reset_index(drop=True)


def main():
    parser = argparse.ArgumentParser(description="Calculate questionnaire coding reliability.")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--output", type=Path, default=DEFAULT_OUTPUT)
    args = parser.parse_args()

    full_dir = args.data_dir / "types-annotator 1"
    blind_dir = args.data_dir / "types-annotator 2"
    full_files = sorted(p for p in full_dir.glob("*.xlsx") if not p.name.startswith("~$"))
    blind_files = sorted(p for p in blind_dir.glob("*.xlsx") if not p.name.startswith("~$"))

    full_rows = []
    for path in full_files:
        full_rows.extend(read_coding_file(path))

    blind_rows = []
    for path in blind_files:
        blind_rows.extend(read_coding_file(path))

    full_lookup = defaultdict(list)
    for r in full_rows:
        key = (r["No."], r["Generation"], r["Response"])
        full_lookup[key].append(r)

    compared = []
    ambiguous = []
    for i, blind in enumerate(blind_rows, start=1):
        key = (blind["No."], blind["Generation"], blind["Response"])
        matches = full_lookup.get(key, [])
        coding_candidates = sorted({m["Coding"] for m in matches if m["Coding"] in CATEGORIES})
        base = {
            "No.": blind["No."],
            "Emoji": blind["Emoji"],
            "Generation": blind["Generation"],
            "Blind row": i,
            "Response": blind["Response"],
            "Reviewer coding": blind["Coding"],
            "Matched full rows": ";".join(str(full_rows.index(m) + 1) for m in matches[:20]),
        }
        if len(coding_candidates) == 1:
            original = coding_candidates[0]
            compared.append(
                {
                    **base,
                    "Original coding": original,
                    "Agreement": "Yes" if original == blind["Coding"] else "No",
                    "Status": "matched",
                }
            )
        else:
            ambiguous.append(
                {
                    **base,
                    "Original coding candidates": "|".join(coding_candidates),
                    "Reason": "Same response text matched no unique original coding; excluded from kappa and agreement denominator.",
                }
            )

    summary_rows = []
    summary_rows.append(
        {
            "Scope": "Overall",
            "Total review records": len(blind_rows),
            "Excluded ambiguous": len(ambiguous),
            **{k: v for k, v in summarize(compared, "Overall").items() if k != "Scope"},
        }
    )
    for generation, scope in [("00后", "Post-00s"), ("80后", "Post-80s")]:
        subset = [r for r in compared if r["Generation"] == generation]
        excluded = [r for r in ambiguous if r["Generation"] == generation]
        summary_rows.append(
            {
                "Scope": scope,
                "Total review records": sum(1 for r in blind_rows if r["Generation"] == generation),
                "Excluded ambiguous": len(excluded),
                **{k: v for k, v in summarize(subset, scope).items() if k != "Scope"},
            }
        )
    summary = pd.DataFrame(summary_rows)

    by_emoji = []
    for no in sorted({r["No."] for r in blind_rows}):
        usable = [r for r in compared if r["No."] == no]
        excluded = [r for r in ambiguous if r["No."] == no]
        if not usable:
            continue
        label = usable[0]["Emoji"]
        row = {
            "No.": no,
            "Emoji": label,
            "Usable N": len(usable),
            "Excluded": len(excluded),
            "Agreements": sum(r["Agreement"] == "Yes" for r in usable),
            "Disagreements": sum(r["Agreement"] == "No" for r in usable),
        }
        obs, exp, kap = cohen_kappa(
            [r["Original coding"] for r in usable],
            [r["Reviewer coding"] for r in usable],
        )
        row["Percent agreement"] = obs
        row["Cohen's kappa"] = kap
        by_emoji.append(row)
    by_emoji = pd.DataFrame(by_emoji)

    disagreements = pd.DataFrame([r for r in compared if r["Agreement"] == "No"])
    compared_df = pd.DataFrame(compared)
    ambiguous_df = pd.DataFrame(ambiguous)
    notes = pd.DataFrame(
        [
            ["Matching unit", "Each blind review row was matched to the full coding file by emoji number, generation group, and exact response text."],
            ["Usable records", "Rows with a unique original coding, or duplicated full rows sharing the same original coding, were included."],
            ["Excluded records", "Rows where the same response text did not map to a unique original coding were excluded from percentage agreement and Cohen's kappa."],
            ["Agreement metric", "Percent agreement and unweighted Cohen's kappa were calculated between initial coding and blind review coding."],
            ["Coding labels", "; ".join(CATEGORIES)],
        ],
        columns=["Item", "Description"],
    )

    args.output.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(args.output, engine="openpyxl") as writer:
        summary.to_excel(writer, index=False, sheet_name="Summary")
        by_emoji.to_excel(writer, index=False, sheet_name="By Emoji")
        confusion_matrix(compared).to_excel(writer, index=False, sheet_name="Confusion Matrix Overall")
        confusion_matrix([r for r in compared if r["Generation"] == "00后"]).to_excel(writer, index=False, sheet_name="Confusion Matrix 00后")
        confusion_matrix([r for r in compared if r["Generation"] == "80后"]).to_excel(writer, index=False, sheet_name="Confusion Matrix 80后")
        compared_df.to_excel(writer, index=False, sheet_name="All Compared Rows")
        disagreements.to_excel(writer, index=False, sheet_name="Disagreements")
        ambiguous_df.to_excel(writer, index=False, sheet_name="Ambiguous Excluded")
        notes.to_excel(writer, index=False, sheet_name="Notes")

    print(f"Saved: {args.output.resolve()}")


if __name__ == "__main__":
    main()

