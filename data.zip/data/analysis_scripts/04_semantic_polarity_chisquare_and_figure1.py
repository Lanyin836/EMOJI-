#!/usr/bin/env python3
"""
Reproduce semantic polarity scores, Table 2 chi-square tests, and Figure 1.

Purpose
-------
This script uses Annotator 1's complete five-category coding files to calculate:

- five-category counts for each emoji and generation group;
- polarity scores used in Figure 1;
- quadrant assignment;
- Pearson chi-square tests for intergenerational differences in the full
  five-category semantic distribution;
- Cramer's V effect sizes;
- a reproducible quadrant plot.

Default input folder
--------------------
data/types-annotator 1/

Default outputs
---------------
emoji_semantic_polarity_scores_20_items_by_filename.xlsx
Figure1_quadrant_distribution.png
"""

from __future__ import annotations

import argparse
import math
import os
import re
import tempfile
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(tempfile.gettempdir()) / "matplotlib-cache"))

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


DEFAULT_DATA_DIR = Path("/Users/lanyin/Desktop/Plos one revision/data")
DEFAULT_OUTPUT_XLSX = Path("emoji_semantic_polarity_scores_20_items_by_filename.xlsx")
DEFAULT_OUTPUT_FIGURE = Path("Figure1_quadrant_distribution.png")
CATEGORIES = ["正向类", "负向类", "戏谑类", "中性类", "不熟悉类"]

CANONICAL_LABELS = {
    1: "赞",
    2: "流泪",
    3: "看",
    4: "捂脸",
    5: "玫瑰",
    6: "比心",
    7: "泪奔",
    8: "微笑",
    9: "泣不成声",
    10: "OK",
    11: "九转大肠",
    12: "舔屏",
    13: "呲牙",
    14: "尬笑",
    15: "偷笑",
    16: "送心",
    17: "色",
    18: "猪头",
    19: "不失礼貌的微笑",
    20: "抱抱你",
}


def clean(value):
    if value is None or pd.isna(value):
        return ""
    return str(value).strip()


def parse_no_label(path: Path) -> tuple[int, str]:
    match = re.match(r"\s*(\d+)[\._、\s-]*(.+)", path.stem)
    if not match:
        raise ValueError(f"Could not parse emoji number from filename: {path.name}")
    no = int(match.group(1))
    label = CANONICAL_LABELS.get(no, match.group(2).strip())
    return no, label


def find_header_row(df: pd.DataFrame) -> int:
    for i in range(len(df)):
        row = [clean(x) for x in df.iloc[i].tolist()]
        if "00后 response" in row and "80后 response" in row:
            return i
    raise ValueError("Could not find coding table header row.")


def read_coding_file(path: Path) -> dict:
    no, label = parse_no_label(path)
    raw = pd.read_excel(path, sheet_name=0, header=None, dtype=str)
    header_idx = find_header_row(raw)
    header = [clean(x) for x in raw.iloc[header_idx].tolist()]
    data = raw.iloc[header_idx + 1 :].copy()
    data.columns = header

    out = {"No.": no, "Emoji": label, "Source file": str(path)}
    for generation in ["00后", "80后"]:
        coding_col = f"{generation} reviewer coding"
        codes = [clean(x) for x in data[coding_col].tolist()]
        codes = [x for x in codes if x in CATEGORIES]
        counts = {cat: codes.count(cat) for cat in CATEGORIES}
        n = sum(counts.values())
        out[f"{generation} N"] = n
        for cat in CATEGORIES:
            out[f"{generation} {cat}"] = counts[cat]
        out[f"{generation} positive proportion"] = counts["正向类"] / n
        out[f"{generation} negative proportion"] = counts["负向类"] / n
        out[f"{generation} polarity"] = (
            out[f"{generation} positive proportion"]
            - out[f"{generation} negative proportion"]
        )
    return out


def quadrant(x, y):
    if x >= 0 and y >= 0:
        return "I: both positive"
    if x < 0 and y >= 0:
        return "II: 00s negative / 80s positive"
    if x < 0 and y < 0:
        return "III: both negative"
    return "IV: 00s positive / 80s negative"


def chi_square_test(table):
    """Pearson chi-square test for a 2 x k table.

    Columns with zero total are removed. The p-value is calculated using closed
    forms for df=3 and df=4, which are the only degrees of freedom produced by
    the present data after zero-total columns are removed.
    """
    arr = np.asarray(table, dtype=float)
    arr = arr[:, arr.sum(axis=0) > 0]
    row_sum = arr.sum(axis=1)
    col_sum = arr.sum(axis=0)
    total = arr.sum()
    expected = np.outer(row_sum, col_sum) / total
    chi2 = float(((arr - expected) ** 2 / expected).sum())
    df = int((arr.shape[0] - 1) * (arr.shape[1] - 1))
    p = chi_square_survival(chi2, df)
    cramers_v = math.sqrt(chi2 / (total * (min(arr.shape) - 1)))
    return chi2, df, p, cramers_v


def chi_square_survival(chi2, df):
    z = chi2 / 2.0
    if df == 4:
        return math.exp(-z) * (1 + z)
    if df == 3:
        return math.erfc(math.sqrt(z)) + (2 * math.sqrt(z) * math.exp(-z) / math.sqrt(math.pi))
    if df == 2:
        return math.exp(-z)
    raise ValueError(f"Unsupported df={df}; install scipy for a general chi-square survival function.")


def build_results(data_dir: Path):
    folder = data_dir / "types-annotator 1"
    files = sorted(
        (p for p in folder.glob("*.xlsx") if not p.name.startswith("~$")),
        key=lambda p: parse_no_label(p)[0],
    )
    rows = [read_coding_file(path) for path in files]

    counts_rows = []
    polarity_rows = []
    table2_rows = []
    fig_rows = []
    for r in rows:
        no = r["No."]
        label = r["Emoji"]
        counts_row = {
            "No.": no,
            "emoji label": label,
            "00后 N": r["00后 N"],
            "80后 N": r["80后 N"],
            "Source file": r["Source file"],
        }
        for generation in ["00后", "80后"]:
            for cat in CATEGORIES:
                counts_row[f"{generation} {cat}"] = r[f"{generation} {cat}"]
        counts_rows.append(counts_row)

        x = r["00后 polarity"]
        y = r["80后 polarity"]
        q = quadrant(x, y)
        polarity_rows.append(
            {
                "No.": no,
                "emoji label": label,
                "00后 N": r["00后 N"],
                "00后 positive n": r["00后 正向类"],
                "00后 negative n": r["00后 负向类"],
                "00后 positive proportion": r["00后 positive proportion"],
                "00后 negative proportion": r["00后 negative proportion"],
                "00后 polarity": x,
                "80后 N": r["80后 N"],
                "80后 positive n": r["80后 正向类"],
                "80后 negative n": r["80后 负向类"],
                "80后 positive proportion": r["80后 positive proportion"],
                "80后 negative proportion": r["80后 negative proportion"],
                "80后 polarity": y,
                "80后-00后 polarity": y - x,
                "Quadrant": q,
                "Source file": r["Source file"],
            }
        )
        fig_rows.append(
            {
                "No.": no,
                "emoji label": label,
                "x_00后_polarity": x,
                "y_80后_polarity": y,
                "Quadrant": q,
                "Label": f"{no}. {label}",
            }
        )

        table = [
            [r[f"00后 {cat}"] for cat in CATEGORIES],
            [r[f"80后 {cat}"] for cat in CATEGORIES],
        ]
        chi2, df, p, v = chi_square_test(table)
        table2_rows.append(
            {
                "No.": no,
                "emoji": label,
                "χ²": chi2,
                "df": df,
                "p-value": "<0.001" if p < 0.001 else round(p, 3),
                "p-value numeric": p,
                "Cramér's V": v,
            }
        )

    return (
        pd.DataFrame(polarity_rows),
        pd.DataFrame(counts_rows),
        pd.DataFrame(fig_rows),
        pd.DataFrame(table2_rows),
    )


def write_workbook(output_path, polarity, counts, fig_data, table2):
    notes = pd.DataFrame(
        [
            ["Polarity formula", "polarity score = positive proportion - negative proportion"],
            ["Denominator", "Playful, neutral, and unfamiliar responses are retained in the denominator but are not assigned positive or negative polarity."],
            ["Table 2 test", "Pearson chi-square test on a 2 x 5 table: generation group by semantic coding category."],
            ["Cramer's V", "Calculated as sqrt(chi-square / (N * (min(rows, columns)-1)))."],
        ],
        columns=["Item", "Description"],
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with pd.ExcelWriter(output_path, engine="openpyxl") as writer:
        polarity.to_excel(writer, index=False, sheet_name="Polarity Scores")
        counts.to_excel(writer, index=False, sheet_name="Five-category Counts")
        fig_data.to_excel(writer, index=False, sheet_name="Fig 1 Data")
        table2.to_excel(writer, index=False, sheet_name="Table 2 Chi-square")
        notes.to_excel(writer, index=False, sheet_name="Notes")


def plot_figure(fig_data: pd.DataFrame, output_path: Path):
    colors = {
        "I: both positive": "#2e7d32",
        "II: 00s negative / 80s positive": "#1565c0",
        "III: both negative": "#c62828",
        "IV: 00s positive / 80s negative": "#ef6c00",
    }
    fig, ax = plt.subplots(figsize=(9.5, 7.2), dpi=220)
    for _, r in fig_data.iterrows():
        ax.scatter(
            r["x_00后_polarity"],
            r["y_80后_polarity"],
            s=300,
            color=colors[r["Quadrant"]],
            edgecolor="white",
            linewidth=1.3,
            zorder=3,
        )
        ax.text(
            r["x_00后_polarity"],
            r["y_80后_polarity"],
            str(int(r["No."])),
            ha="center",
            va="center",
            fontsize=9,
            color="black",
            zorder=4,
        )

    ax.axhline(0, color="#222222", linewidth=1.2)
    ax.axvline(0, color="#222222", linewidth=1.2)
    ax.grid(True, color="#d0d7de", linewidth=0.8, alpha=0.7)
    ax.set_xlim(-0.72, 0.72)
    ax.set_ylim(-0.62, 0.76)
    ax.set_xlabel("Post-00s polarity score (negative → positive)")
    ax.set_ylabel("Post-80s polarity score (negative → positive)")
    ax.text(-0.61, 0.63, "Quadrant II\nPost-00s negative\nPost-80s positive",
            ha="left", va="top", bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#9aa4b2"))
    ax.text(0.47, 0.64, "Quadrant I\nBoth positive",
            ha="center", va="top", bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#9aa4b2"))
    ax.text(-0.23, -0.49, "Quadrant III\nBoth negative",
            ha="center", va="top", bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#9aa4b2"))
    ax.text(0.43, -0.45, "Quadrant IV\nPost-00s positive\nPost-80s negative",
            ha="center", va="top", bbox=dict(boxstyle="round,pad=0.25", fc="white", ec="#9aa4b2"))

    note = (
        "Note. Polarity score = positive proportion - negative proportion. "
        "Playful, neutral, and unfamiliar responses are retained in the denominator."
    )
    fig.text(0.08, 0.02, note, fontsize=8, color="#555555")
    fig.tight_layout(rect=(0, 0.05, 1, 1))
    output_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(output_path, bbox_inches="tight")
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description="Calculate semantic polarity, chi-square tests, and Figure 1.")
    parser.add_argument("--data-dir", type=Path, default=DEFAULT_DATA_DIR)
    parser.add_argument("--output-xlsx", type=Path, default=DEFAULT_OUTPUT_XLSX)
    parser.add_argument("--output-figure", type=Path, default=DEFAULT_OUTPUT_FIGURE)
    args = parser.parse_args()

    polarity, counts, fig_data, table2 = build_results(args.data_dir)
    write_workbook(args.output_xlsx, polarity, counts, fig_data, table2)
    plot_figure(fig_data, args.output_figure)
    print(f"Saved: {args.output_xlsx.resolve()}")
    print(f"Saved: {args.output_figure.resolve()}")


if __name__ == "__main__":
    main()
